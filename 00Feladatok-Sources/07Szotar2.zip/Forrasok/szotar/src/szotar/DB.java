package szotar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import static panel.Panel.hiba;

/**
 *
 * @author Joe
 */
public class DB {
    final String db = "jdbc:mysql://localhost:3306/szotar" +
                      "?useUnicode=true&characterEncoding=UTF-8";
    final String user = "tanulo";		
    final String pass = "tanulo";
    
    public void beolvas(ObservableList<Szo> tabla, String s) {
        try (Connection kapcs = DriverManager.getConnection(db, user, pass);
             PreparedStatement ekp = kapcs.prepareStatement(s)) {
            tabla.clear();
            ResultSet eredmeny = ekp.executeQuery();
            while (eredmeny.next()) {
                tabla.add(new Szo(
                    eredmeny.getInt("szoId"),
                    eredmeny.getString("lecke"),
                    eredmeny.getString("angol"),
                    eredmeny.getString("magyar")
                ));
            }
        } catch (SQLException ex) {
            hiba("Hiba!",ex.getMessage());
            Platform.exit();
        }
    }    

}
