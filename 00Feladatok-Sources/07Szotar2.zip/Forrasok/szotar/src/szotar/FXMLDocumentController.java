package szotar;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author Joe
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Tab tabSzotar;

    @FXML
    private TextField txtLeckeSzuro;

    @FXML
    private TextField txtAngolSzuro;

    @FXML
    private TextField txtMagyarSzuro;

    @FXML
    private TableView<Szo> tblSzavak;

    @FXML
    private TableColumn<Szo, String> oLecke;

    @FXML
    private TableColumn<Szo, String> oAngol;

    @FXML
    private TableColumn<Szo, String> oMagyar;

    @FXML
    private TextField txtLecke;

    @FXML
    private TextField txtAngol;

    @FXML
    private TextField txtMagyar;

    @FXML
    void hozzaad() {

    }

    @FXML
    void modosit() {

    }

    @FXML
    void szuro_torol() {
        txtLeckeSzuro.clear();
        txtAngolSzuro.clear();
        txtMagyarSzuro.clear();
        tblSzavak.requestFocus();
    }

    @FXML
    void torol() {

    }

    @FXML
    void uj() {

    }

    private void beolvas() {
        String szuro1 = "'%" + txtLeckeSzuro.getText() + "%'";
        String szuro2 = "'%" + txtAngolSzuro.getText() + "%'";
        String szuro3 = "'%" + txtMagyarSzuro.getText() + "%'";
        String s = "SELECT * FROM szavak "
                + "WHERE lecke LIKE " + szuro1
                + "AND   angol LIKE " + szuro2
                + "AND  magyar LIKE " + szuro3
                + " ORDER BY angol;";
        ab.beolvas(tblSzavak.getItems(), s);
    }

    private void tablabol(int i) {
        if (i == -1) {
            return;
        }
        Szo sz = tblSzavak.getItems().get(i);
        txtLecke.setText("" + sz.getLecke());
        txtAngol.setText("" + sz.getAngol());
        txtMagyar.setText("" + sz.getMagyar());
    }


    DB ab = new DB();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        oLecke.setCellValueFactory(new PropertyValueFactory<>("lecke"));
        oAngol.setCellValueFactory(new PropertyValueFactory<>("angol"));
        oMagyar.setCellValueFactory(new PropertyValueFactory<>("magyar"));

        beolvas();

        txtLeckeSzuro.textProperty().addListener((o, regi, uj) -> beolvas());
        txtAngolSzuro.textProperty().addListener((o, regi, uj) -> beolvas());
        txtMagyarSzuro.textProperty().addListener((o, regi, uj) -> beolvas());

        tblSzavak.getSelectionModel().selectedIndexProperty().addListener(
                (o, regi, uj) -> tablabol(uj.intValue())
        );

    }

// tanulás
    @FXML
    private ComboBox<String> cbxValaszt;

    @FXML
    private Button btnIndit;

    @FXML
    private Button btnTudtam;

    @FXML
    private Button btnNemTudtam;

    @FXML
    private Label lblFelso;

    @FXML
    private Label lblAlso;

    @FXML
    private Label lblHanyvan;

    @FXML
    void indit() {

    }

    @FXML
    void mutat() {

    }

    @FXML
    void nem_tudtam() {

    }

    @FXML
    void tudtam() {

    }

}
